# 1.5b 
scatterplot = scan("sampleA.txt")
plot(scatterplot, main="ScatterPlot 1.5B") # scatterplot

