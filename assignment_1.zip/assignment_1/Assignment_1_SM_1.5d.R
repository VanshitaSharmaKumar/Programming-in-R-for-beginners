sampleB = scan("sampleB.txt")
hist(sampleB, prob = T, xlab = "x", ylab = "y", main="The Histogram (Exercise 1.5d)")

# boxplot(boxplot1)
quantile(sampleB,c(0, 0.25,0.75,1)) # the quantiles of the boxplot
# quantile values:  0%       25%       75%      100% 
#               5.693107  7.058678 11.099486 17.404498 
boxplot(sampleB, main="Boxplot 1.5D", ylab = "y",ylim=c(0,16))
plot(sampleB, main="ScatterPlot 1.5D", ylab="y", xlab="x") # scatterplot
