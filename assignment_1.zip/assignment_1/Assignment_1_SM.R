#Question 1.5a 
histogram1 = scan("sampleA.txt")
hist(histogram1, prob = T, xlab = "x", ylab = "y", main="The Histogram (Exercise 1.5a)")

boxplot1 = scan("sampleA.txt")
# boxplot(boxplot1)
quantile(boxplot1,c(0, 0.25,0.75,1)) # the quantiles of the boxplot
# quantile values:  0%       25%       75%      100% 
#               5.693107  7.058678 11.099486 17.404498 

boxplot(boxplot1, main="Boxplot 1.5a", ylab = "y",ylim=c(0,16))
