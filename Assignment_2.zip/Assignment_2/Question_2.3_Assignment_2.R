library(ggplot2)

#Question 2.3a i. 
# creating a qqplot of sample size 115 
chi_graph = rchisq(115,2)
qqnorm(chi_graph, main = "QQ Plot of Chi-Squared") 
# plotting chi_graph as qqplot. 


#Question 2.3a ii. 
# creating a qqplot of sample size 105 
ypos <- rt(105, 4)
qqnorm(ypos,main = "QQ Plot of T-distribution")
