titanic = read.csv("titanic3.csv")
hist(titanic$age,xlab = "Age of Passengers", ylab = "y", main="Titianic Histogram")
boxplot(titanic$age, main="Titanic Boxplot", ylab = "Age of Passengers",ylim=c(0,85))
qqnorm(titanic$age, main="Titanic QQ plot", ylab="Age of Passengers")
