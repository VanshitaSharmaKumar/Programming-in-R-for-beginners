diabetes = read.csv("diabetes.csv")
hist(diabetes$chol, xlab = "Cholesterol Level of Individuals", ylab = "y", main="Diabetes Histogram",breaks=10)
boxplot(diabetes$chol, main="Diabetes Boxplot", ylab = "Cholesterol Level of Individuals")
qqnorm(diabetes$chol, main="Diabetes QQ plot", ylab="Cholesterol Level of Individuals")