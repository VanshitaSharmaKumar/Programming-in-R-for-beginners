vlbw = read.csv("vlbw.csv")
hist(vlbw$bwt, xlab = "Weights", ylab = "y", main="Birth Weights Histogram")
boxplot(vlbw$bwt, main="Birth Weight Boxplot", ylab = "Weights")
qqnorm(vlbw$bwt, main="Birth Weight QQ plot", ylab="Weights")

