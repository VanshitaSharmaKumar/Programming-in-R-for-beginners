chi_graph = rchisq(115,2)
ypos = rt(105, 4)

#histogram of chi squared
hist(chi_graph, prob = T, xlab = "x", ylab = "y", main="Histogram of Chi-squared")

#box-plot of chi squared
boxplot(chi_graph, main="Boxplot of Chi-squared", ylab = "y")

#histogram of t-distribution
hist(ypos, prob = T, xlab = "x", ylab = "y", main="Histogram of t-distribution",breaks=10)

#box-plot of t-distribution
boxplot(ypos, main="Boxplot of t-distribution", ylab = "y")


